package com.example.newsinfosapp

class User(
    var name:String,
    var psw:String,
    var tel:String
) {
}