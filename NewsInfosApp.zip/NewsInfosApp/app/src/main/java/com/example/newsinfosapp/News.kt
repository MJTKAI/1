package com.example.newsinfosapp

class News(
    var uniquekey:String,
    var type:String,
    var title:String,
    var thumbnail_pic_s:String,
    var url:String,
    var author_name:String,
    var date:String
) {

}